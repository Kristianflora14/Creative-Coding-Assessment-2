let amp;
function preload (){
sound=loadSound('doggie.mp3');
}
function setup() {
createCanvas (400, 400);
sound.loop();
amp=new p5.Amplitude();
}

function draw() {
background (0,10);
let level = amp.getLevel();
fill(random(255), random(255), random (255));
  
let size = map(level, 0,1,0, width/2);
circle(width/2, height/2, size*10 );
}