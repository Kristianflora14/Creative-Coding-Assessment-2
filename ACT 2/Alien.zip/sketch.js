function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(20, 20, 40); 

  
  fill(100, 255, 100);
  ellipse(200, 200, 180, 220);

  
  fill(0);
  ellipse(160, 180, 40, 70);
  ellipse(240, 180, 40, 70);

  
  stroke(0);
  line(180, 250, 222, 250);
}