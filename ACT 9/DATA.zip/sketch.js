let table;

function preload() {
  table = loadTable('data2.csv', 'csv', 'header');
}

function setup() {
  createCanvas(600, 400);
  background(255);

  let barHeight = 30;

  for (let i = 0; i < table.getRowCount(); i++) {
    let nationality = table.getString(i, 'Nationality');
    let population = table.getNum(i, 'Population');

    let y = 30 + i * (barHeight + 20);


    let w = map(population, 0, 6, 0, width - 100);

    fill(0);
    rect(100, y, w, barHeight);

    fill(0);
    textAlign(RIGHT, CENTER);
    textSize(12);
    text(nationality, 90, y + barHeight / 2);

    fill(255);
    textAlign(RIGHT, CENTER);
    text(population + "%", 100 + w - 5, y + barHeight / 2);
  }
}