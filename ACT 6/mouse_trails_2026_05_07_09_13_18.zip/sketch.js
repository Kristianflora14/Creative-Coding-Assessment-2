function setup() {
  createCanvas(400, 400);
  background(0);
}

function draw() {
 

  fill(random(255), random(255), random(255), 100);
  noStroke();

  ellipse(mouseX, mouseY, 20);
}