function setup() {
  createCanvas(400, 200);
}

function draw() {
  background(200);

 
  fill(100, 6, 6); 
  rect(100, 100, 200, 50);

  
  rect(140, 70, 120, 40);

  
  fill(0); 
  ellipse(140, 150, 40, 40);
  ellipse(260, 150, 40, 40);
}