function setup() {
  createCanvas(400, 400);
  background(0);
}

function draw() {
  fill(random(255), random(255), random(255), 150);
  noStroke();
  ellipse(mouseX, mouseY, random(10, 40));
}

function mousePressed() {
  background(random(255), random(255), random(255));
}