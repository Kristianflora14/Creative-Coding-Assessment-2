var pink = document.getElementById("red");
var blue = document.getElementById("orange");
var counter = 0;

function jump(){
    red.classList.add("animate"); 

    setTimeout(function(){
        red.classList.remove("animate");
    }, 400);
}

var check = setInterval(function(){
    let redTop = parseInt(window.getComputedStyle(red).getPropertyValue("top"));
    let orangeLeft = parseInt(window.getComputedStyle(orange).getPropertyValue("left"));

    if (orangeLeft < 20 && orangeLeft > -20 && redTop >= 130){
        orange.style.animation = "none";

        alert("Game Over. Score: " + counter / 100);
        counter = 0;

        orange.style.animation = "move 2s infinite linear";
    } else{
        counter++;
        document.getElementById("scoreSpan").innerHTML = counter / 100;
    } 

}, 10);