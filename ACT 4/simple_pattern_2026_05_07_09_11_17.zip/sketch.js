function setup() {
  createCanvas(400, 400);
  background(220);

  
  for (let x = 0; x < width; x += 40) {
    for (let y = 0; y < height; y += 40) {

      
      fill(random(255), random(255), random(255));

      
      ellipse(x, y, 20);
    }
  }
}