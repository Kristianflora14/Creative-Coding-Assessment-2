var word = "Wspp Kriz";
var font1;
function preload()
{
  font1 = loadFont("fonts/neonlore-demo.regular.ttf");
}

function setup(){
  createCanvas(600, 400);
  background (0);
  fill(255);
  textFont(font1, 100);
  textAlign(CENTER);
  text(word, 300,200);
}
